-- ============================================================
-- MG EDITÁVEIS / CNH DIGITAL - BANCO DE DADOS MYSQL
-- Execute este arquivo no phpMyAdmin / MySQL da sua VPS
-- ============================================================

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `cnhs`;
DROP TABLE IF EXISTS `recargas`;
DROP TABLE IF EXISTS `usuarios`;
DROP TABLE IF EXISTS `configuracoes`;
DROP TABLE IF EXISTS `ips_bloqueados`;
SET FOREIGN_KEY_CHECKS=1;

-- ------------------------------------------------------------
-- 1. TABELA DE USUÁRIOS (CLIENTES E ADM)
-- ------------------------------------------------------------
CREATE TABLE `usuarios` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `senha` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `saldo` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `role` ENUM('admin', 'client') NOT NULL DEFAULT 'client',
  `status` ENUM('pending', 'approved', 'blocked') NOT NULL DEFAULT 'pending',
  `register_ip` VARCHAR(64) DEFAULT NULL,
  `last_ip` VARCHAR(64) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inserindo o Usuário Administrador Oficial e Contas de Teste
INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `phone`, `saldo`, `role`, `status`) VALUES
(1, 'Administrador Geral MG', 'MG', 'Comida12.@', '(21) 99882-1029', 9999.00, 'admin', 'approved'),
(2, 'Administrador Alternativo', 'moritzpj@gmail.com', 'Comida12.@', '(21) 99882-1029', 1170.00, 'admin', 'approved'),
(3, 'LUCAS FRANCISCO DA SILVA', 'lucas.francisco@gmail.com', '123456', '(21) 98712-4410', 240.00, 'client', 'approved'),
(4, 'CARLOS EDUARDO ROCHA', 'carlosedu@hotmail.com', '123456', '(11) 97401-2299', 0.00, 'client', 'pending'),
(5, 'RENATO ALVES VELOSO', 'renato.veloso@gmail.com', '123456', '(41) 98833-1020', 120.00, 'client', 'blocked');

-- ------------------------------------------------------------
-- 2. TABELA DE RECARGAS & SOLICITAÇÕES DE PIX
-- ------------------------------------------------------------
CREATE TABLE `recargas` (
  `id` VARCHAR(30) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `user_nome` VARCHAR(150) NOT NULL,
  `valor` DECIMAL(10,2) NOT NULL,
  `metodo` VARCHAR(50) NOT NULL DEFAULT 'PIX QrCode',
  `status` ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
  `data` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_recargas_user` (`user_id`),
  CONSTRAINT `fk_recargas_user` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dados Iniciais de Recargas
INSERT INTO `recargas` (`id`, `user_id`, `user_nome`, `valor`, `metodo`, `status`, `data`) VALUES
('REC-4091', 3, 'LUCAS FRANCISCO DA SILVA', 200.00, 'PIX QrCode', 'pending', '2026-10-09 13:50:00'),
('REC-4090', 4, 'CARLOS EDUARDO ROCHA', 100.00, 'PIX Copia e Cola', 'pending', '2026-10-09 13:10:00'),
('REC-4089', 1, 'Administrador Geral MG', 500.00, 'PIX Instantâneo', 'approved', '2026-10-09 11:20:00');

-- ------------------------------------------------------------
-- 3. TABELA DE CNHS GERADAS
-- ------------------------------------------------------------
CREATE TABLE `cnhs` (
  `id` VARCHAR(30) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `user_nome` VARCHAR(150) NOT NULL,
  `nome_cnh` VARCHAR(150) NOT NULL,
  `cpf` VARCHAR(20) NOT NULL,
  `rg` VARCHAR(30) DEFAULT NULL,
  `categoria` VARCHAR(10) NOT NULL DEFAULT 'AB',
  `valor_cobrado` DECIMAL(10,2) NOT NULL DEFAULT 26.00,
  `dados_json` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_cnhs_user` (`user_id`),
  CONSTRAINT `fk_cnhs_user` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 3.1 TABELA DE EXAMES TOXICOLÓGICOS GERADOS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `exames` (
  `id` VARCHAR(30) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `user_nome` VARCHAR(150) NOT NULL,
  `nome_paciente` VARCHAR(150) NOT NULL,
  `cpf` VARCHAR(20) NOT NULL,
  `laudo` VARCHAR(50) NOT NULL,
  `resultado` VARCHAR(100) NOT NULL DEFAULT 'Negativo',
  `dados_json` LONGTEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_exames_user` (`user_id`),
  CONSTRAINT `fk_exames_user` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- 4. TABELA DE CONFIGURAÇÕES DO SISTEMA (INCLUINDO 3 DOMÍNIOS)
-- ------------------------------------------------------------
CREATE TABLE `configuracoes` (
  `chave` VARCHAR(100) NOT NULL,
  `valor` LONGTEXT NOT NULL,
  PRIMARY KEY (`chave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inserindo Configurações Globais Padrão
INSERT INTO `configuracoes` (`chave`, `valor`) VALUES
('cnh_price', '26.00'),
('min_recharge', '25.00'),
('pix_key', 'financeiro@mgeditaveis.com'),
('dominioPainel', 'http://painel-mg-editaveis.com'),
('dominioQrCode', 'https://consulta-senatran.com'),
('dominioApp', 'https://cnh-brasil-web-app.com'),
('webapp_customization', '{"heroBanner":"","logoImage":null,"govHeaderLogo":null,"logoText":"CNH","logoSub":"DO BRASIL","pwaTitle":"CNH DO BRASIL","pwaSub":"Adicione à tela inicial","pwaBtnText":"Instalar","updateTitle":"APP ATUALIZADO\\nAPP CNH DO BRASIL","downloadUrl":"","downloadBtnText":"BAIXAR NOVA VERSÃO","btnText":"ENTRAR COM gov.br","btnColor":"#255ab8"}');

-- ------------------------------------------------------------
-- 5. TABELA DE SEGURANÇA E IPS BLOQUEADOS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `ips_bloqueados` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `ip` VARCHAR(64) NOT NULL,
  `motivo` VARCHAR(255) NOT NULL,
  `user_id` INT(11) DEFAULT NULL,
  `user_email` VARCHAR(150) DEFAULT NULL,
  `user_agent` TEXT DEFAULT NULL,
  `data` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
